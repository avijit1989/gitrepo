package hello;

/**
 * Created by Avi on 03-02-2016.
 */

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class HelloController {

    @RequestMapping("/")
    public String index() {
        return "Greetings from Spring Boot!";
    }
    @RequestMapping("/tellmeaboutyourself")
    public String tellMeAboutYourself() {
        return "Hi I am an application built with spring-boot";
    }

}
